Abibas is a fork/extension of Gamaliel, a geometric blackletter by Rafael Ferran i Peralta. It was meant to be a contribution to that project, but I could find no contact information. Abibas is my way of sharing these additions until such time as they are folded back into Gamaliel itself.

http://christtrekker.users.sourceforge.net